arr=".BaseTopologyManager.ip4=\"$1\""
./jq $arr "./config/sample-gvpn-config.json" > "./config/gvpn-config.json"
