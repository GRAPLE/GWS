ps aux | grep -v grep | grep ipop-tincan | awk '{print $2}' | xargs sudo kill -9
ps aux | grep -v grep | grep controller.Controller | awk '{print $2}' | xargs sudo kill -9
