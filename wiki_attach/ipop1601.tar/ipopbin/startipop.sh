#!/bin/bash
cd $(dirname $0)
sudo -b ./ipop-tincan 1> ./tin.log 2> ./tin.err
python -m controller.Controller -c ./config/gvpn-config.json 1> ./con.log 2> ./con.err &
